import * as React from 'react';
import * as Icon from 'react-feather';
import styled from 'styled-components/macro';
import { useEffect } from 'react';
import tw from 'twin.macro';

const HideShowIcon = styled.div`
    & > *{
        transition:transform .3s;
    }
    .stellar-collapsed & > * {
        transform:rotate(180deg);
    }
`

export default () => {
    const collapseClass = 'stellar-collapsed'; 

    useEffect(() => {
        const isCollapsed = localStorage.getItem('collapse');
        if (isCollapsed) {
            localStorage.removeItem('collapse');
            document.body.classList.remove('collapse');
        }
        if (localStorage.getItem('collapse_stellar') === 'true') {
             document.body.classList.add(collapseClass);
        }
    }, []);

    const collapseBtn = () => {
        if (document.body.classList.contains(collapseClass)){
            localStorage.setItem('collapse_stellar', 'false');
            document.body.classList.remove(collapseClass);
        } else {
            localStorage.setItem('collapse_stellar', 'true');
            document.body.classList.add(collapseClass);
        }
    }

    return (
        <button onClick={collapseBtn}>
            <div className='icon'>
                <HideShowIcon>
                    <span css={tw`hidden md:block`}>
                        <Icon.ArrowLeft size={20}/>
                    </span>
                    <span css={tw`block md:hidden`}>
                         <Icon.ArrowUp size={20}/>
                    </span>
                </HideShowIcon>
            </div>
        </button>
    );
};
